library(methods)
library(knitr)
library('ggplot2')


.Hbeta <- function(D, beta){
  P = exp(-D * beta)
  sumP = sum(P)
  if (sumP == 0){
    H = 0
    P = D * 0
  } else {
    H = log(sumP) + beta * sum(D %*% P) /sumP
    P = P/sumP
  }
  r = {}
  r$H = H
  r$P = P
  r
}

.x2p <- function(X, perplexity = 15,tol = 1e-5){
  D = as.matrix(X)
  n = dim(D)[1]
  P = matrix(0, n, n )
  beta = rep(1, n)
  logU = log(perplexity)
  for (i in 1:n){
    betamin = -Inf
    betamax = Inf
    Di = D[i, -i]
    hbeta = .Hbeta(Di, beta[i])
    H = hbeta$H;
    thisP = hbeta$P
    Hdiff = H - logU;
    tries = 0;

    while(abs(Hdiff) > tol && tries < 50){
      if (Hdiff > 0){
        betamin = beta[i]
        if (is.infinite(betamax)) beta[i] = beta[i] * 2
        else beta[i] = (beta[i] + betamax)/2
      } else{
        betamax = beta[i]
        if (is.infinite(betamin))  beta[i] = beta[i]/ 2
        else beta[i] = ( beta[i] + betamin) / 2
      }

      hbeta = .Hbeta(Di, beta[i])
      H = hbeta$H
      thisP = hbeta$P
      Hdiff = H - logU
      tries = tries + 1
    }
    P[i,-i]  = thisP
  }

  r = {}
  r$P = P
  r$beta = beta
  sigma = sqrt(1/beta)

  # message('sigma summary: ', paste(names(summary(sigma)),':',summary(sigma),'|',collapse=''))

  r
}


#' Graph-based clustering method with various types of distances based on L-infinity, L-1, and L-2 norms. 
#'
#' This function returns the cluster assignment
#' @param X cell-by-gene expression matrix
#' @param krange number of clusters range, default 1:10
#' @param perp perplexity
#' @param distType distance type, default L-infinity distance,
#'                  including (maximum, euclidean, manhattan)
#' @param seed random seed
#' @return An array of all cluster assignments corresponding to different perplexity and number of clusters
#' @export

LD_SC_clu <- function(X, krange = 1:10, perp = seq(5, 50, 5),
                      distType = "maximum", seed = 1205){
  # Args:
  #   X: a N * p gene expression matrix (cell * gene); can also be a dist
  #      object
  #   krange: a vector, indicating the cluster number candidates, default value
  #      1:10
  #   perp: a vector, indicating the perplexity candidates.
  #   distType : distance types including "maximum" (based on L-infinity norm), "euclidean" (based on L-2 norm), "manhattan" (based on L-1 norm)
  #   seed : random seed
  # Output:
  #   A 3-dimensinal array, store cluster membership information at each k and p
  if (!is(X, "dist"))
    X <- dist(X, method = distType)
  X <- as.matrix(X)
  n <- nrow(X)
  r <- vector("list", length(perp)); W <- r; L <- W; eigL <- L
  for (i in 1:length(perp)){
    r[[i]] <- .x2p(X, perp[i], tol = 1e-5)
    W[[i]] <- r[[i]]$P
    # Construct Laplacian matrix L = D - W
    L[[i]] <- -W[[i]]
    diag(L[[i]]) <- rowSums(W[[i]]) - diag(W[[i]])
    eigL[[i]] <- eigen(L[[i]])
  }
  output <- array(NA, c(length(krange), length(perp), n))


  pcount <- 1
  for (p in perp){
    kcount <- 1
    for (k in krange){
      U <- eigL[[pcount]]$vectors[, (n - k + 1):n]
      Ud <- dist(U)
      set.seed(seed = seed)
      tmp <- hclust(Ud, method = "ward.D2")
      result <- cutree(tmp, k)
      output[kcount, pcount, ] <- result
      kcount <- kcount + 1
    }
    pcount <- pcount + 1
  }
  return(output)
}



#' Calculate a Gap-statistic type of criterion
#'
#' This function returns the Gap-statistic type of criterion.
#' @param data cell-by-gene expression matrix
#' @param clusterF clustering function
#' @param distType distance types including "maximum" (based on L-infinity norm), "euclidean" (based on L-2 norm), "manhattan" (based on L-1 norm)
#' @param pre_output result from LD_SC_clu
#' @param K range of cluster numbers
#' @param P perplexity
#' @param B Number of bootstrap samples
#' @param spaceH0 reference distribution, can be selected from scaledPCA and original
#' @param d_X distance matrix, if NULL, will be computed from data
#' @param seed random seed
#' @return An array of Gap statistics
#' @export

GAP_statistic <- function(data, clusterF, pre_output, distType = c("maximum"),
                          K = 1:10, P = seq(5, 50, 5),
                          B = 20, spaceH0 = c("scaledPCA", "original"),
                          d_X = NULL, seed = 1205){
  # Args:
  #  data: n * p matrix (cell * gene)
  #  clusterF: clustering function
  #  pre_output: 3-dim array
  #  K: a vector of number of clusters
  #  B: number of bootstrap samples
  #  P: perplexity
  #  seed: random seed
  # Uniformly generate reference distribution
  #browser()
  n <- nrow(data)
  if (is.null(d_X))
    d_X <- dist(data, method = distType)
  ii <- seq_len(n)
  W <- function(d_X, clu_mat) {
    # d_X is a matrix, not dist
    single.w <- function(clu){
      # Here all distances are counted twice, therefore divided by 4, not 2
      0.25 * sum(vapply(split(ii, clu),
                        function(I) {
                          sum(d_X[I, I, drop = F]) / length(I)
                        }, 0))
    }
    apply(clu_mat, c(1, 2), single.w)
  }
  # Step 1: Get clustering logW
  logW_mat <- log(W(as.matrix(d_X), pre_output))
  # Step 2: Boostrap
  set.seed(seed)
  spaceH0 <- match.arg(spaceH0)
  xs <- scale(data, center = TRUE, scale = FALSE)
  m.x <- rep(attr(xs, "scaled:center"), each = n)
  switch(spaceH0, scaledPCA = {
    V.sx <- svd(xs, nu = 0)$v
    xs <- xs %*% V.sx
  }, original = {xs <- xs
  }, stop("invalid 'spaceH0':", spaceH0))

  rng.x1 <- apply(xs, 2L, range)
  ElogW_all <- array(NA, c(length(K), length(P), B))
  for (b in 1:B){
    z1 <- apply(rng.x1, 2, function(M, nn) runif(nn, min = M[1],
                                                 max = M[2]), nn = n)
    z <- switch(spaceH0, scaledPCA = tcrossprod(z1, V.sx),
                original = z1) + m.x
    d_z <- dist(z, method = distType)
    pre_res <- LD_SC_clu(d_z, K, P, distType, seed)
    ElogW_all[, , b] <- log(W(as.matrix(d_z), pre_res))
  }
  ElogW_mat <- apply(ElogW_all, c(1, 2), mean)
  SE <- sqrt((1 + 1 / B) * apply(ElogW_all, c(1, 2), var))
  return(list(gap = ElogW_mat - logW_mat, SE = SE))
}

#' Select the tuning parameters through Gap-statistic type of criterion.
#'
#' This function returns the selected cluster membership
#' @param clumat Cluster assignments generated by LD_SC_clu
#' @param gapmat Gap statistics and standard deviations generated by GAP_statistic
#' @param method Suggest to be "SE" (default)
#' @param prefix path for plots
#' @param K range of cluster numbers
#' @param perp perplexity
#' @return Cluster membership
#' @examples
#'set.seed(721)
#'dat <- matrix(rnorm(10000), 100, 10)
#'dat[1:10, ] <- dat[1:10, ] + 5
#'dat[51:100, ] <- dat[51:100, ] - 5
#'input_prefix    <- "./"
#'output_pathLinf <- paste(input_prefix, "Linf", sep = '')
#'K <- 1:10
#'perp <- c(seq(5, 55, 10), c(70, 100, 150, 200, 300, 500))
#'
#'SeedLinf   <- 1205
#'res  <- LD_SC_clu(dat, krange = K, perp = perp, distType = "maximum", SeedLinf)
#'gap  <- GAP_statistic(dat, LD_SC_clu, res, distType = "maximum",  K, perp, spaceH0 = "original")
#'
#'clu  <- as.factor(SelectClu2(res, gap, method = "SE", output_pathLinf, K, perp)[[1]])
#'clu
#' @export

SelectClu2 <- function(clumat, gapmat, method = "SE", prefix, K, perp){
  # Args:
  #   clumat: a 3-dimensional array, stores cluster membership
  #   gapmat: a list, stores gap statistic of all (p, k) combinations
  # Outputs:
  #   a vector indicating the clustering assignments
  #browser()
  E <- gapmat[[1]]; SE <- gapmat[[2]]
  Upper <- E + SE; Lower <- E - SE
  # Step 1: check optimal number of cluster at each perp
  mat <- NULL
  for (pcount in 1:ncol(clumat)){
    tmp <- .SelectSingleGap(E[, pcount], Upper[, pcount], Lower[, pcount],
                            plot = 1,
                            path = paste(prefix, "_Perp", perp[pcount], ".png", sep = ""),
                            main = paste("Perplexity =", perp[pcount]))
    mat <- rbind(mat, tmp)
  }
  # Step 2: check optimal perp
  selected_perp <- NULL
  for (k in nrow(mat):2)
    # first enter the increasing trend
    if (mat[k, 2] < mat[k - 1, 2])
      break
  for (kk in (k - 1):2){
    if (mat[kk, 2] > mat[kk - 1, 2]){
      selected_perp <- kk; break
    }
  }
  if (is.null(selected_perp))
    selected_perp <- 1
  png(paste(prefix, "_SelectPerp.png", sep = ""),
      width = 7, height = 7, units = 'in', res = 300)
  plot(1:nrow(mat), mat[, 2], type = "b", cex = 0.7, pch = 19,
       xlab = "Perplexity", ylab = "Gap",
       ylim = c(min(mat[, 4]), max(mat[, 3])), col = "dark red", xaxt="n")
  title("Perplexity vs Gap-statistic")
  arrows(1:nrow(mat), mat[, 3], 1:nrow(mat), mat[, 4],
         length=0.05, angle=90, code=3)
  abline(v = selected_perp, lty = 2)
  axis(1, at = 1:nrow(mat), labels = perp)
  dev.off()
  res <- list(clumat[mat[selected_perp, 1], selected_perp, ],mat[selected_perp, 1],selected_perp)
  return(res)
}

.SelectSingleGap <- function(e, up, low, plot = 1, path = NULL, main = NULL){
  if (plot){
    png(path,
        width = 7, height = 7, units = 'in', res = 300)
    plot(1:length(e), e, type = "b", cex = 0.7, pch = 19,
         xlab = "Number of Clusters", ylab = "Gap",
         ylim = c(min(low), max(up)), col = "dark red")
    title(main)
    arrows(1:length(e), low, 1:length(e), up, length=0.05, angle=90, code=3)
  }
  for (i in 1:(length(e) - 1))
    if (e[i] > low[i + 1]){
      if (plot){
        abline(v = i, lty = 2)
        dev.off()
      }
      return(c(i, e[i], up[i], low[i]))
    }
  i <- length(e)
  if (plot){
    abline(v = i, lty = 2)
    dev.off()
  }
  return(c(i, e[i], up[i], low[i]))
}



