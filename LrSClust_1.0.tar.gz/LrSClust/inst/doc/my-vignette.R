## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- warning = FALSE---------------------------------------------------------
# Step 1 
# Download file 'LrSClust_0.1.0.tar.gz'

# Step 2 Install package 'LrSClust': 
# open R, run following codes
# packagepath <- "./LrSClust_1.0.tar.gz" (The path # of the 'LrSClust_0.1.0.tar.gz')
# packagedir  <- choose.files(packagepath)
# install.packages(packagedir, repos=NULL)


# Step 3 View document
# open R, run following codes
# browseVignettes('LrSClust')

## ----setup--------------------------------------------------------------------
library(LrSClust)

dat           <- matrix(rnorm(10000), 100, 10)
dat[1:10, ]   <- dat[1:10, ] + 5
dat[51:100, ] <- dat[51:100, ] - 5

## ----warning=FALSE------------------------------------------------------------

# File path ("./" : current working directory)
input_prefix    <- "./"
output_pathLinf <- paste(input_prefix, "Linf", sep = '')

# Initial Parameters
K    <- 1:10
perp <- c(seq(5, 55, 10), c(70, 100, 150, 200, 300, 500))

## ----warning=FALSE------------------------------------------------------------

# Start Clustering 
SeedLinf   <- 1205
res  <- LD_SC_clu(dat, krange = K, perp = perp, distType = "maximum", SeedLinf)

gap  <- GAP_statistic(dat, LD_SC_clu, distType = "maximum", res, K, perp, spaceH0 = "original")

## ----warning=FALSE------------------------------------------------------------

# Clustering result of Linf 
clu  <- as.factor(SelectClu2(res, gap, method = "SE", output_pathLinf, K, perp)[[1]])

clu

